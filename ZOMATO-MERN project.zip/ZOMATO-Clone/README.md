# Zomato Clone Project

Frontend+Backend - usingReact, AWS, MongoDb, Redux, Node/Express

Google authentication
----------------------
![signup](https://user-images.githubusercontent.com/84318379/137154455-86dddbe5-7520-4b36-b080-079eaa92067b.png)  

Map
----
![map](https://user-images.githubusercontent.com/84318379/137154958-60f0526b-548b-4f61-bef7-2f86be32300c.png)

Integrate Razorpay payment gateway
--------------------------
![payment](https://user-images.githubusercontent.com/84318379/137156040-30ecd365-af27-4a3f-94ea-c09fdad991b0.png)

 Pages
--------
![deli](https://user-images.githubusercontent.com/84318379/137154222-46727df4-acc6-4fab-a376-e92213763929.png)
![restaurent0](https://user-images.githubusercontent.com/84318379/137155219-91b49348-5765-4df1-a6b9-9e9645b071a2.png)
![restaurent1](https://user-images.githubusercontent.com/84318379/137155333-8698e3c2-b26b-4bd3-b30a-ffc99d02ca12.png)
![deliver](https://user-images.githubusercontent.com/84318379/137154305-e0b3a0cd-c14e-4e21-8d8e-bd051a232da3.png)
![respo](https://user-images.githubusercontent.com/84318379/137154658-ed74fb2d-2494-4d11-b280-96a3982f4cdd.png)





